# Front-end Style Guide

## Layout

The designs were created to the following widths:

- Mobile: 375px
- Desktop: 1440px

> 💡 These are just the design sizes. Ensure content is responsive and meets WCAG requirements by testing the full range of screen sizes from 320px to large screens.

## Colors


--white: #ffffff;
--eggshell: #f3e6d8;
--light-grey: #e4ded8;
--wenge-brown: #5f574e;
--dark-charcoal: #302d2c;
--nutmeg: #854632;
--dark-raspberry: #7b284f;
--rose-white: #fff5fa;

## Typography

### Body Copy

- Font size (paragraph): 16px

### Fonts

- Family: [Young Serif](https://fonts.google.com/specimen/Young+Serif)
- Weights: 400

- Family: [Outfit](https://fonts.google.com/specimen/Outfit)
- Weights: 400, 600, 700
